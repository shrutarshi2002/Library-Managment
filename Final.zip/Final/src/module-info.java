class addition
{
  public static void main (String args [])
  {
    int A=20;
    int B=30;
    int C=A+B;
System.out.println("The name is"+C);
}
}
